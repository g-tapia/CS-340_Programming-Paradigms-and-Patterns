module Main where

import MP5b

main :: IO ()
main = do
  _ <- playAI 3
  return ()
